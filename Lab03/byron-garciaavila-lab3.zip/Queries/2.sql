SELECT s_suppkey, MIN(s_acctbal)
FROM Supplier
