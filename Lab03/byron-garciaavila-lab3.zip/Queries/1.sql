SELECT c_address, c_phone
FROM customer
WHERE c_custkey = 000000227